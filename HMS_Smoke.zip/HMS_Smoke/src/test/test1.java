package test;

import java.util.List;
import java.io.File;
import java.sql.SQLException;
import java.util.ArrayList;

import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.DocumentBuilder;
import org.w3c.dom.Document;
import org.w3c.dom.NodeList;
import org.w3c.dom.Node;
import org.w3c.dom.Element;
import org.w3c.dom.NamedNodeMap;

import java.io.File;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import org.junit.Rule;
import  org.w3c.dom.Document;

import base.Function_Lib;
import utilities.JIRAUtility;

public class test1 {
	public static void main(String args[]) throws ClassNotFoundException, SQLException {
		
		String xmlPath="E:\\Jira_Plugin\\HMS_Smoke\\test-output\\Functionalresult.xml";
		test1 t=new test1();
		t.readJunitXMLFile(xmlPath);
	}
		public static void readJunitXMLFile(String XMLPath)
		{
			try
			{ 
				
				/*Function_Lib lib = new Function_Lib();
				String DB_Path = System.getProperty("user.dir") + "\\src\\resources\\AutoDefectLogging.accdb";
				JIRAUtility jiraUtility = new JIRAUtility();
				String pathToAttachment =System.getProperty("user.dir") + "\\test-output\\html\\screenshots\\Login.png";*/
			File xmlFile=new File(XMLPath);
			DocumentBuilderFactory dbFactory=DocumentBuilderFactory.newInstance();
			DocumentBuilder dbBuilder=dbFactory.newDocumentBuilder();
			Document doc=dbBuilder.parse(xmlFile);
			doc.getDocumentElement().normalize();
		     NodeList nList  = doc.getElementsByTagName("testcase");
		      
				
		      for (int i = 0; i <nList.getLength(); i++) {
		          NamedNodeMap map = nList.item(i).getAttributes();
		          String s=map.getNamedItem("name").getNodeValue();
		          String testCaseName=map.getNamedItem("name").getNodeValue();
		          System.out.println("map is:"+testCaseName);
		          if(nList.item(i).hasChildNodes()==true)
		          {
		        	  System.out.println("attachment");
		        	 // lib.updateLocalDBandJIRA(DB_Path, testCaseName, "Failed",pathToAttachment);
		          }
		          else
		          {
		          System.out.println("No Attachment");
		         // lib.updateLocalDBandJIRA(DB_Path, testCaseName, "Passed");
		          }
		      }
			}
			catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			
			

	}
		}


