package test;

import org.testng.Assert;
import org.testng.annotations.Test;

import pages.HomePage;
import pages.LoginPage;

public class LoginTest {

	/**
	 * Check login functionality Verify it displays valid text after name
	 */
	@Test(priority = 1)
	public void Login() {
		LoginPage loginPage = new LoginPage();
		loginPage.navigateToPage();
		loginPage.doLogin();
		HomePage homePage = new HomePage();
		Assert.assertTrue(homePage.getLblUserName().getText().equals("Hi, John Paul"));
	}

	/**
	 * Check logout functionality
	 */
	@Test(priority = 2)
	public void Logout() {
		HomePage homePage = new HomePage();
		homePage.getBtnLogout().click();

		homePage.waitForPageToLoad();

		Assert.assertTrue(homePage.getTxtUserName().isDisplayed());
		Assert.assertTrue(homePage.getTxtPassword().isDisplayed());

	}
}