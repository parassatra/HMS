package pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import base.TestBase;

public class HomePage extends LoginPage {

	public HomePage() {
		// TODO Auto-generated constructor stub
		PageFactory.initElements(TestBase.getDriver(), this);
	}

	@FindBy(xpath = "//a[text()='Home']")
	private WebElement menuHome;

	@FindBy(xpath = "//a[text()='Blood']")
	private WebElement menuBlood;

	@FindBy(xpath = "//a[text()='Banks']")
	private WebElement menuBanks;
	
	@FindBy(xpath = ".//table[@id='ctl00_NavigationMenu']//a[text()='Finance']")
	private WebElement menuFinance;
	
	@FindBy(xpath = "//a[text()='BillsPaymentandHistory']")
	private WebElement menuBillPaymentHistory;
	
	@FindBy(id = "ctl00_lblLoginUser")
	private WebElement lblUserName	;
	
	@FindBy(id = "ctl00_lbtnLogOut")
	private WebElement btnLogout	;
	
	public WebElement getLblUserName() {
		return lblUserName;
	}

	public WebElement getBtnLogout() {
		return btnLogout;
	}

	public WebElement getMenuFinance() {
		return menuFinance;
	}

	public WebElement getMenuBillPaymentHistory() {
		return menuBillPaymentHistory;
	}

	public WebElement getMenuBlood() {
		return menuBlood;
	}

	public WebElement getMenuBanks() {
		return menuBanks;
	}

	public WebElement getMenuHome() {
		return menuHome;
	}

}
