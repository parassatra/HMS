package pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import base.Function_Lib;
import base.TestBase;

public class LoginPage extends Function_Lib {

	public LoginPage() {
		// TODO Auto-generated constructor stub
		PageFactory.initElements(TestBase.getDriver(), this);
	}

	@FindBy(id = "txtUserID")
	private WebElement txtUserName;

	@FindBy(id = "txtPassword")
	private WebElement txtPassword;

	@FindBy(id = "btnLogin")
	private WebElement btnLogin;

	public WebElement getTxtUserName() {
		return txtUserName;
	}

	public WebElement getTxtPassword() {
		return txtPassword;
	}

	public WebElement getBtnLogin() {
		return btnLogin;
	}

	public void navigateToPage() {
		TestBase.getDriver().get(TestBase.getProperties().getProperty("AUT_URL"));
	}
	
	
	public void doLogin(){
		txtUserName.sendKeys(TestBase.getProperties().getProperty("UserName"));
		txtPassword.sendKeys(TestBase.getProperties().getProperty("Password"));
		btnLogin.click();
	}

}
