package utilities;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.sql.ResultSet;

import org.apache.commons.codec.binary.Base64;
import org.apache.http.HttpResponse;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.mime.HttpMultipartMode;
import org.apache.http.entity.mime.MultipartEntity;
import org.apache.http.entity.mime.content.FileBody;
import org.apache.http.impl.client.DefaultHttpClient;

import com.google.gson.JsonIOException;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.google.gson.JsonSyntaxException;

import base.Function_Lib;
import base.TestBase;

@SuppressWarnings("deprecation")
public class JIRAUtility extends Function_Lib {

	String JIRA_userID = TestBase.getProperties().getProperty("jira_server_username");
	String JIRA_pass = TestBase.getProperties().getProperty("jira_server_password");
	String authString = JIRA_userID + ":" + JIRA_pass;
	String authToken = "Basic " + new String(Base64.encodeBase64(authString.getBytes()));
	String jira_endpoint = TestBase.getProperties().getProperty("jira_api");
	String assigneeuserID = TestBase.getProperties().getProperty("jira_devAssignee");

	/**
	 * It will create JIRA issue with given details and returns defect id
	 * 
	 * @param payload
	 * @return
	 */
	public String createJiraIssue(String TestCaseID, String db_path, String... pathToScreenShot) {
		try {
			String defect_id = null;
			String api_CreateIssue = jira_endpoint + "/issue/";
			// create json
			// providing project specific json file path
			DBUtility dbfunctions = new DBUtility();
			dbfunctions.setDb_path(db_path);
			ResultSet rs = dbfunctions.select("Select * from testCases where testCaseid = '" + TestCaseID + "'");

			Object input_obj = (new JsonParser())
					.parse(new FileReader(System.getProperty("user.dir") + "\\src\\json\\createJiraIssue.json"));
			JsonObject issueJson = (JsonObject) input_obj;
			JsonObject fields = issueJson.getAsJsonObject("fields");
			while (rs.next()) {
				fields.addProperty("summary", rs.getString("TESTCASENAME"));
				fields.addProperty("description", rs.getString("TestCaseDesc"));
			}
			FileWriter file = new FileWriter(System.getProperty("user.dir") + "\\src\\json\\createJiraIssue.json");
			file.write(issueJson.toString());
			file.close();
			String response = getJSONResponse(api_CreateIssue, authToken, "POST", input_obj.toString());
			Object output_obj = (new JsonParser()).parse(response);
			JsonObject outputJson = (JsonObject) output_obj;
			defect_id = outputJson.get("id").getAsString();
			addAttachment(defect_id, pathToScreenShot[0]);
			return defect_id;
		} catch (Exception e) {
			e.printStackTrace();
			return "";
		}

	}

	@SuppressWarnings({ "resource" })
	public void addAttachment(String defectID, String pathToAttachment) {
		HttpClient httpclient = new DefaultHttpClient();
		HttpPost httppost = new HttpPost(jira_endpoint + "/issue/" + defectID + "/attachments");
		httppost.setHeader("X-Atlassian-Token", "nocheck");
		httppost.setHeader("Authorization", authToken);
		MultipartEntity entity = new MultipartEntity(HttpMultipartMode.BROWSER_COMPATIBLE);

		File fileToUpload = new File(pathToAttachment);
		FileBody fileBody = new FileBody(fileToUpload, "application/octet-stream");
		entity.addPart("file", fileBody);

		httppost.setEntity(entity);
		HttpResponse response = null;
		try {
			response = httpclient.execute(httppost);
		} catch (ClientProtocolException e) {
		} catch (IOException e) {
		}

		if (response.getStatusLine().getStatusCode() == 200)
			System.out.println("Screenshot was attached for defect id " + defectID + " with path " + pathToAttachment);
		else
			System.out
					.println("Screenshot wasn't attached for defect id " + defectID + " with path " + pathToAttachment);

	}

	public void addComment(String comment, String defectID) {
		try {
			String api_comment = jira_endpoint + "/issue/" + defectID + "/comment?expand";
			Object input_obj = (new JsonParser())
					.parse(new FileReader(System.getProperty("user.dir") + "\\src\\json\\addComment.json"));
			JsonObject commentJson = (JsonObject) input_obj;
			commentJson.addProperty("body", comment);

			FileWriter file = new FileWriter(System.getProperty("user.dir") + "\\src\\json\\addComment.json");
			file.write(commentJson.toString());
			file.close();
			Thread.sleep(3000);
			getJSONResponse(api_comment, authToken, "POST", input_obj.toString());

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * This method is called when testcase is being closed
	 */
	public void closeIssue(String defectID) {
		System.out.println("Inside updateStatus");
		String api_statusChange = jira_endpoint + "/issue/" + defectID + "/transitions?expand=transitions.field";
		String jsonString = modifyID_statusChangeJSON("51").toString();
		System.out.println("this is "+ jsonString);
		// Change status from New to Assigned
//		getJSONResponse(api_statusChange, authToken, "POST", modifyID_statusChangeJSON("21").toString());
		// Change status from Assigned to In Progress
		getJSONResponse(api_statusChange, authToken, "POST", jsonString);
		// Change status from In Progress to Fixed
//		getJSONResponse(api_statusChange, authToken, "POST", modifyID_statusChangeJSON("111").toString());
		// Change status from Fixed to Ready to test
//		getJSONResponse(api_statusChange, authToken, "POST", modifyID_statusChangeJSON("121").toString());
		// Change status from Ready to test to Closed"
//		getJSONResponse(api_statusChange, authToken, "POST", modifyID_statusChangeJSON("131").toString());

	}

	public Object modifyID_statusChangeJSON(String id) {
		Object input_obj = null;
		try {
			input_obj = (new JsonParser())
					.parse(new FileReader(System.getProperty("user.dir") + "\\src\\json\\statusChange.json"));
			System.out.println(input_obj.toString());
		} catch (JsonIOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (JsonSyntaxException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		JsonObject commentJson = (JsonObject) input_obj;
		commentJson.addProperty("id", id);
		return input_obj;
	}

}
