package utilities;

import java.io.FileInputStream;
import java.io.FileOutputStream;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import dnl.utils.text.table.TextTable;

public class ExcelUtility {

	private static XSSFSheet ExcelWSheet;

	private static XSSFWorkbook ExcelWBook;

	private static XSSFCell Cell;

	private static XSSFRow Row;

	// This method is to set the File path and to open the Excel file, Pass
	// Excel Path and Sheetname as Arguments to this method

	public static void setExcelFile(String Path, String SheetName) {

		try {
			// Open the Excel file

			FileInputStream ExcelFile = new FileInputStream(Path);

			// Access the required test data sheet

			ExcelWBook = new XSSFWorkbook(ExcelFile);
			ExcelWSheet = ExcelWBook.getSheet(SheetName);

		} catch (Exception e) {

			try {
				throw (e);
			} catch (Exception e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}

		}

	}

	// This method is to read the test data from the Excel cell, in this we are
	// passing parameters as Row num and Col num

	public static String getCellData(int RowNum, int ColNum) {

		try {

			Cell = ExcelWSheet.getRow(RowNum).getCell(ColNum);

			String CellData = Cell.getStringCellValue();

			return CellData;

		} catch (Exception e) {
			System.out.println(e);
			e.printStackTrace();
			return "";

		}
	}

	// This method is to write in the Excel cell, Row num and Col num are the
	// parameters

	public static void setCellData(String Result, int RowNum, int ColNum, String path) throws Exception {

		Cell = ExcelWSheet.getRow(RowNum).getCell(ColNum);
		if (Cell == null) {
			Cell = Row.createCell(ColNum);
			Cell.setCellValue(Result);
		} else {
			Cell.setCellValue(Result);
		}

		// Constant variables Test Data path and Test Data file name
		FileOutputStream fileOut = new FileOutputStream(path);
		ExcelWBook.write(fileOut);
		fileOut.flush();
		fileOut.close();
	}

	/**
	 * It will fetch row number by given test case name
	 * 
	 * @param testCaseName
	 * @return
	 */
	public static int getTCRowNum(String testCaseName) {
		int numberOfRows = ExcelWSheet.getLastRowNum();
		int row = 0;
		for (int i = 1; i <= numberOfRows; i++) {
			String cellText = ExcelWSheet.getRow(i).getCell(1).getStringCellValue();
			if (cellText.equals(testCaseName)) {
				row = i;
				break;
			}
		}
		return row;
	}

	/**
	 * It will filter result table from Excel and print the risk table on
	 * console
	 */
	public static void printRiskTableOnConsole(String path) {
		int numberOfRows = ExcelWSheet.getLastRowNum();
		String[] columnNames = new String[6];
		int failCount = 0;
		for (int j = 1; j <= numberOfRows; j++) {
			String resultValue = ExcelWSheet.getRow(j).getCell(5).getStringCellValue();
			if (("FAIL").equalsIgnoreCase(resultValue)) {
				failCount++;
			}
		}

		String[][] rowData = new String[failCount][6];
		// Create array with header row
		for (int k = 0; k <= 5; k++) {
			String cellHeader = ExcelWSheet.getRow(0).getCell(k).getStringCellValue();
			columnNames[k] = cellHeader;
		}

		int rowIndex = 0;
		for (int i = 1; i <= numberOfRows; i++) {
			String cellText = ExcelWSheet.getRow(i).getCell(5).getStringCellValue();
			if (cellText.equals("FAIL")) {
				for (int j = 0; j <= 5; j++) {
					String tableCell = "";
					if (j == 4) {
						int TC_Impact = (int) ExcelWSheet.getRow(i).getCell(2).getNumericCellValue();
						int TC_probability = (int) ExcelWSheet.getRow(i).getCell(3).getNumericCellValue();
						int riskScore = TC_Impact * TC_probability;
						tableCell = riskScore + "";
					} else {
						XSSFCell cell = ExcelWSheet.getRow(i).getCell(j);
						switch (cell.getCellType()) {
						case 1:
							tableCell = ExcelWSheet.getRow(i).getCell(j).getStringCellValue();
							break;
						case 0:
							tableCell = ExcelWSheet.getRow(i).getCell(j).getNumericCellValue() + "";
							break;
						}
					}
					rowData[rowIndex][j] = tableCell;
				}
				rowIndex++;
			}

		}
		TextTable t1 = new TextTable(columnNames, rowData);
		t1.setAddRowNumbering(true);
		t1.printTable();
	}

}
