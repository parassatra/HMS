package utilities;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Timestamp;

public class DBUtility {

	Connection conn = null;
	ResultSet rs = null;
	String db_path = null;

	public String getDb_path() {
		return db_path;
	}

	public void setDb_path(String db_path) {
		this.db_path = db_path;
	}

	public void connect(String path) {
		try {
			Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
			this.conn = DriverManager.getConnection("jdbc:ucanaccess://" + path);
		}

		catch (Exception e) {
			System.err.println("Got an exception! ");
			System.err.println(e.getMessage());
		}
	}

	public void disconnect() {
		try {
			this.conn.close();
		} catch (Exception e) {
			System.err.println("Got an exception! ");
			System.err.println(e.getMessage());

		}
	}

	public Connection getConn() {
		return conn;
	}

	public void setConn(Connection conn) throws IOException {
		this.conn = conn;
	}

	public void updateSQL(String sqlQuery) throws SQLException, IOException {
		connect(db_path);
		this.conn.setAutoCommit(true);
		PreparedStatement stmt = this.conn.prepareStatement(sqlQuery);
		stmt.executeUpdate();
		stmt.close();
		disconnect();
	}

	public ResultSet select(String sqlQuery) {
		ResultSet rs = null;
		try {
			connect(this.db_path);
			Statement st = this.conn.createStatement();
			rs = st.executeQuery(sqlQuery);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		disconnect();
		return rs;
	}

	public void updateTestRunStatusTable(String testCaseid, String runStatus) {
		ResultSet rsTestRunStatus = select("Select * from TestRunStatus where TestCaseId = '" + testCaseid + "'");
		Timestamp timestamp = new Timestamp(System.currentTimeMillis());
		// If there is no record in 'TestRunStatus' table then insert row else
		// update the row
		try {
			if (!rsTestRunStatus.next()) {
				// No row is there for test case,hence inserting record
				updateSQL("insert into TestRunStatus (TestCaseId,RunStatus,TimeStamp) values('" + testCaseid + "','"
						+ runStatus + "','" + timestamp + "')");
			} else {
				// Row exist, hence Updating test run status
				updateSQL("UPDATE TestRunStatus SET RunStatus = '" + runStatus + "', TimeStamp = '" + timestamp
						+ "' WHERE testCaseiD = '" + testCaseid + "'");
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public void deleteRowDefectTable(String testCaseid, String defectId) {
		try {
			updateSQL("delete from Defects WHERE TestCaseID = '" + testCaseid + "'");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	public void insertDefectTable(String testCaseid, String defectId) {
		try {
			updateSQL("insert into Defects (DefectID,TestCaseID) values('" + defectId + "','" + testCaseid + "')");
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

}
