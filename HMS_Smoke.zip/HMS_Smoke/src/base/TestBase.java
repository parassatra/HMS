package base;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class TestBase {

	// Initiate webdriver for IE and maximize the window
	static ThreadLocal<WebDriver> driver = new ThreadLocal<WebDriver>() // webdriver
	{
		@Override
		protected WebDriver initialValue() {
//			String dir = System.getProperty("user.dir");
//			System.setProperty("webdriver.ie.driver", dir + "\\drivers\\IEDriverServer.exe");
			return new FirefoxDriver();
		}
	};

	public static WebDriver getDriver() {
		driver.get().manage().window().maximize();
		return driver.get();
	}

	public static Properties getProperties() {
		String dir = System.getProperty("user.dir");
		File file = new File(dir + "\\src\\resources\\base.properties");

		FileInputStream fileInput = null;
		try {
			fileInput = new FileInputStream(file);
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
		Properties prop = new Properties();

		// load properties file
		try {
			prop.load(fileInput);
		} catch (IOException e) {
			e.printStackTrace();
		}
		return prop;
	}

	// Quits the driver and closes the browser
	public static void quit() {
		driver.get().quit();
		driver.remove();
	}

}
