package base;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.MalformedURLException;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Date;

import org.apache.http.HttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.DefaultHttpClient;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import utilities.DBUtility;
import utilities.JIRAUtility;

@SuppressWarnings("deprecation")
public class Function_Lib {

	public void mouseHover(WebElement element) {
		Actions action = new Actions(TestBase.getDriver());
		action.moveToElement(element).build().perform();
	}

	public void waitForPageToLoad() {
		ExpectedCondition<Boolean> expectation = new ExpectedCondition<Boolean>() {
			public Boolean apply(WebDriver driver) {
				return ((JavascriptExecutor) driver).executeScript("return document.readyState").toString()
						.equals("complete");
			}
		};
		try {
			Thread.sleep(1000);
			WebDriverWait wait = new WebDriverWait(TestBase.getDriver(), 30);
			wait.until(expectation);
		} catch (Throwable error) {
			Assert.fail("Timeout waiting for Page Load Request to complete.");
		}
	}

	public void waitForElement(WebElement element) {
		WebDriverWait wait = new WebDriverWait(TestBase.getDriver(), 30);
		wait.until(ExpectedConditions.visibilityOf(element));
	}

	@SuppressWarnings("resource")
	public static String getJSONResponse(String api, String authHeader, String requestMethod, String... payload) {

		String output = "";
		if (requestMethod == "POST") {
			try {
				DefaultHttpClient httpClient = new DefaultHttpClient();
				HttpPost postRequest = new HttpPost(api);
				postRequest.setHeader("AUTHORIZATION", authHeader);

				StringEntity input = new StringEntity(payload[0]);
				input.setContentType("application/json");
				postRequest.setEntity(input);
				HttpResponse response = httpClient.execute(postRequest);
				if (response.getStatusLine().getStatusCode() != 201) {
					throw new RuntimeException(
							"Failed : HTTP error code : " + response.getStatusLine().getStatusCode());
				}

				BufferedReader br = new BufferedReader(new InputStreamReader((response.getEntity().getContent())));

				output = br.readLine();
				if (output != null) {
					System.out.println("Output from Server .... ");
					System.out.println(output);
				}

			} catch (MalformedURLException e) {

				e.printStackTrace();

			} catch (IOException e) {

				e.printStackTrace();

			}
		}

		return output;
	}

	public void updateLocalDBandJIRA(String db_path, String testCaseId, String runStatus, String... attachmentPath)
			throws SQLException {

		DBUtility strdb = new DBUtility();
		JIRAUtility strjiraUpdate = new JIRAUtility();
		strdb.setDb_path(db_path);

		// Update TestRunStatusTable according to runStatus and existence of row
		// in table
		strdb.updateTestRunStatusTable(testCaseId, runStatus);

		ResultSet rs = strdb.select("Select * from TestCases where TestCaseId = '" + testCaseId + "'");
		ResultSet rsDefect = strdb.select("Select * from Defects where TestCaseID = '" + testCaseId + "'");
		String flagStatus = null;
		String testcasename = null;
		String testcaseid = null;

		while (rs.next()) {
			testcaseid = rs.getString("TestCaseId");
			testcasename = rs.getString("TestCaseName");
			flagStatus = rs.getString("JiraExceFlag");
			System.out.println(testcaseid);
			System.out.println(testcasename);
			System.out.println(flagStatus);
		}

		if (runStatus.equalsIgnoreCase("Passed") && flagStatus.equalsIgnoreCase("true")) {
			System.out.println("Inside passed & JIRA flag true");
			// If defect exists for passed test-case,close the issue in JIRA and
			// delete record from DefectTable
			if (rsDefect.next()) {
				String defectID = rsDefect.getString("DefectID");
				System.out.println("Inside Passed defect id " + defectID);

				strjiraUpdate.closeIssue(defectID);
				//strjiraUpdate.addComment("Run Passed. Please see the latest attached report.",
					//	rsDefect.getString("DefectID"));
				// Delete record in Defect table after closing issue in JIRA
				//strdb.deleteRowDefectTable(testCaseId, defectID);
			}
		} else if (runStatus.equalsIgnoreCase("Failed") && flagStatus.equalsIgnoreCase("true")) {
			if (rsDefect.next()) {
				// Defect exist
				// Read JIRA ticket number from 'Defects' table and update the
				// ticket.
				strjiraUpdate.addAttachment(rsDefect.getString("DefectID"), attachmentPath[0]);
				Date date = new Date();
				// Add comment to corresponding JIRA issue
				strjiraUpdate.addComment(
						"Retest failed on: " + date.toString() + ". Please see the latest log attached",
						rsDefect.getString("DefectID"));
			} else {
				// Defect doesn't exist, hence create a new ticket in JIRA with
				// attachment
				String defect_key = strjiraUpdate.createJiraIssue(testCaseId, db_path, attachmentPath);

				// Update defects table with created defect id
				if (!defect_key.isEmpty()) {
					strdb.insertDefectTable(testCaseId, defect_key);
				} else {
					System.out.println("Issue is not created in JIRA for test case " + testCaseId);
				}
			}
		}
	}

}
