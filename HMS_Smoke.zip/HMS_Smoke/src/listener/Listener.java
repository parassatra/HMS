package listener;

import java.io.File;
import java.io.IOException;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.testng.ISuite;
import org.testng.ISuiteListener;
import org.testng.ITestContext;
import org.testng.ITestListener;
import org.testng.ITestResult;

import base.TestBase;
import utilities.ExcelUtility;

public class Listener implements ISuiteListener, ITestListener {

	WebDriver driver = null;

	String dir = System.getProperty("user.dir");
	String filePath = dir + "\\test-output\\html\\screenshots";

	@Override
	public void onFinish(ISuite arg0) {
		// TODO Auto-generated method stub
		String filePath = System.getProperty("user.dir") + "\\src\\resources\\RBT.xlsx";
//		ExcelUtility.printRiskTableOnConsole(filePath);
		TestBase.quit();
	}

	@Override
	public void onStart(ISuite arg0) {
		// TODO Auto-generated method stub

	}

	@Override
	public void onFinish(ITestContext arg0) {
		// TODO Auto-generated method stub

	}

	@Override
	public void onStart(ITestContext arg0) {
		// TODO Auto-generated method stub

	}

	@Override
	public void onTestFailedButWithinSuccessPercentage(ITestResult arg0) {
		// TODO Auto-generated method stub

	}

	@Override
	public void onTestFailure(ITestResult result) {
		System.out.println("***** Error " + result.getName() + " test has failed *****");
		String methodName = result.getName().toString().trim();
		takeScreenShot(methodName);
		updaeExcelResult(methodName, "FAIL");

	}

	public void takeScreenShot(String methodName) {
		// get the driver
		driver = TestBase.getDriver();
		File scrFile = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
		// The below method will save the screen shot in d drive with test
		// method name
		try {
			String fileSeperator = System.getProperty("file.separator");
			File f = new File(filePath);
			f.mkdir();
			FileUtils.copyFile(scrFile, new File(filePath + fileSeperator + methodName + ".png"));
			System.out.println("***Placed screen shot in " + filePath + " ***");
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	@Override
	public void onTestSkipped(ITestResult result) {
		// TODO Auto-generated method stub
		String methodName = result.getName().toString().trim();
		updaeExcelResult(methodName, "SKIPPED");
	}

	@Override
	public void onTestStart(ITestResult arg0) {
		// TODO Auto-generated method stub

	}

	@Override
	public void onTestSuccess(ITestResult result) {
		// TODO Auto-generated method stub
		String methodName = result.getName().toString().trim();
		updaeExcelResult(methodName, "PASS");

	}

	public void updaeExcelResult(String methodName, String result) {
		String dir = System.getProperty("user.dir");
		String filePath = dir + "\\src\\resources\\RBT.xlsx";
		String sheetName = "Sheet1";
		ExcelUtility.setExcelFile(filePath, sheetName);
		int rowNumber = ExcelUtility.getTCRowNum(methodName);
		try {
			ExcelUtility.setCellData(result.toString(), rowNumber, 5, filePath);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

}
